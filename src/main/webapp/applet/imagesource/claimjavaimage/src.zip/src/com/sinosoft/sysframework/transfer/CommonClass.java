package com.sinosoft.sysframework.transfer;

/**
 * @author lijiyuan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * Author:Mr.Li    lijiyuan create version  1.0 
 */
public interface CommonClass
{
    public static final String PRINT_STRING[] = {
    		"Upload Test....Li.Ji.Yuan(���Ԫljypda@hotmail.com).....Version1.0", 
			"Action...........",
			"======Main Title======",
			"-----Type Title-----",			
			"CollectUNL is connect....",
			"CollectSize  is .... ",			
			"�ϴ�ʧ�ܣ�δ֪����"
        };    
    public static final String  PRE_FIX="PRE";    
    public static final int       STEP1=0x00000002;    
    public static final int       STEP2=0x00000004;
    public static final int       STEP3=0x00000008;
    public static final int       STEP4=0x00000010;
    public static final String  SPLASH="/picdata/databak/testapp/ClaimImages/splash.gif";
    public static final int       RETURNTYPE=6;	
}
