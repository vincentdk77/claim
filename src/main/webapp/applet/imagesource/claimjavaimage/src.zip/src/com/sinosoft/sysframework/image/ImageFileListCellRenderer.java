/**
 * @author lijiyuan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * Author:Mr.Li    lijiyuan create version  1.0 
 */

package com.sinosoft.sysframework.image;
import java.awt.Color;
import java.awt.Component;
import javax.swing.*;
import javax.swing.border.Border;
/**
 * ����ʾ���ƺ�ͼƬ��List������ 
 */
public class ImageFileListCellRenderer extends JLabel
        implements
            ListCellRenderer {
    private Border lineBorder = BorderFactory.createLineBorder(Color.red, 2),
            emptyBorder = BorderFactory.createEmptyBorder(2, 2, 2, 2);
    public ImageFileListCellRenderer() {
        setOpaque(true);
    }
    public Component getListCellRendererComponent(JList list, Object value,
            int index, boolean isSelected, boolean cellHasFocus) {
        ImageFileListModel model = (ImageFileListModel) list
                .getModel();
        setText(model.getName(value));
        setIcon(model.getIcon(value));
        if (isSelected) {
            setForeground(list.getSelectionForeground());
            setBackground(list.getSelectionBackground());
        } else {
            setForeground(list.getForeground());
            setBackground(list.getBackground());
        }
        if (cellHasFocus)
            setBorder(lineBorder);
        else
            setBorder(emptyBorder);
        return this;
    }
}
