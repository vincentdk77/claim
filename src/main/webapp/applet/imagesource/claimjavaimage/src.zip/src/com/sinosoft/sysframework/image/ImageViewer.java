/**
 * @author lijiyuan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * Author:Mr.Li    lijiyuan create version  1.0 
 */

package com.sinosoft.sysframework.image;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Cursor;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;



import com.sinosoft.claim.dto.custom.PrpLImageDto;
import com.sinosoft.claim.dto.domain.PrpLcertifyImgDto;
import com.sinosoft.sysframework.transfer.*;
import com.sinosoft.imagetrans.*;

/**
 * 
 */
public class ImageViewer extends JFrame {
    /**
     * 
     */
public JTextField titleText5 = new JTextField();


    public ImageViewer(String fileName,PrpLImageDto prpLImageDto) throws Exception {
	   String shortFileName = fileName;
	   String tempPath = System.getProperty("java.io.tmpdir");	
	   tempPath = tempPath.replace('\\', '/');
       HttpImageFileListModel httpImageFileListModel = new HttpImageFileListModel();
	   ArrayList collection=httpImageFileListModel.getCollection();

	 
        PrpLImageDto prpLImageShow = new PrpLImageDto(); 
        try{  

	     for (int i = 0; i < collection.size(); i++) {
		PrpLcertifyImgDto prpLcertifyImgDto = (PrpLcertifyImgDto)collection.get(i);
		if (prpLcertifyImgDto.getImgFileName().equals(fileName)){
	 	        prpLImageShow.setRegistNo(prpLcertifyImgDto.getBusinessNo());
	 	        prpLImageShow.setLossItemCode(prpLcertifyImgDto.getLossItemCode()); 
	 	        prpLImageShow.setLossItemName(prpLcertifyImgDto.getLossItemName()); 
	 	        prpLImageShow.setTypeCode(prpLcertifyImgDto.getTypeCode()); 
	 	        prpLImageShow.setTypeName(prpLcertifyImgDto.getPicName()); 
	 	        prpLImageShow.setSignInDate(String.valueOf(prpLcertifyImgDto.getSignInDate())); 
	 	        prpLImageShow.setUploadFileName(prpLcertifyImgDto.getUploadFileName()); 
	 	        prpLImageShow.setImgFileName(prpLcertifyImgDto.getImgFileName()); 
	 	        prpLImageShow.setPicPath(prpLcertifyImgDto.getPicPath()); 
	 	        prpLImageShow.setCollectorName(prpLcertifyImgDto.getCollectorName()); 
	 	        prpLImageShow.setNodeType(prpLcertifyImgDto.getUploadNodeFlag()); 
	 	        prpLImageShow.setDisPlayName(prpLcertifyImgDto.getDisplayName()); 
			}
       	}						
        }catch(Exception ex){
        	ex.printStackTrace();  
        }
        
        //String dir=  tempPath+HttpClient.getRootPath()+prpLImageDto.getFtpSavePath()+"/"+fileName;
        
        //·����Ϊ�����ݿ��ж��ķ�ʽ
        String dir=  tempPath+HttpClient.getRootPath()+prpLImageShow.getPicPath()+"/"+fileName;
        JLabel label = new JLabel(new ImageIcon(dir));

        //������ʱ���� 
        Container ContentPane = this.getContentPane();
        ContentPane.setLayout(new FlowLayout(FlowLayout.LEFT));
        ContentPane.add(new JScrollPane(label), BorderLayout.CENTER);
        
        //JPanel  ��� 
        JPanel jPane = new JPanel(); 
        jPane.setLayout(new GridBagLayout()); 
        //���ĸ�ʽ 
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.BOTH;
        c.weightx=1;
        c.weighty=1;  
        //��һ��
        JLabel titleLabel = new JLabel("ԭ�ļ����ƣ�");
        JLabel titleText1 = new JLabel(prpLImageShow.getUploadFileName());  
        c.gridx=1;
        c.gridy=0; 
        jPane.add(titleLabel,c);  
        c.gridx=2;
        c.gridy=0; 
        jPane.add(titleText1,c);    
        
        //�ڶ���
        JLabel titleLabe2 = new JLabel("ϵͳ��������");
        JLabel titleText2 = new JLabel(prpLImageShow.getImgFileName());  
        c.gridx=1;
        c.gridy=1; 
        jPane.add(titleLabe2,c);  
        c.gridx=2;
        c.gridy=1; 
        jPane.add(titleText2,c);    
        

        //������
        JLabel titleLabe3 = new JLabel("�ϴ��ߣ�");
        JLabel titleText3 = new JLabel(prpLImageShow.getCollectorName());  
        c.gridx=1;
        c.gridy=2; 
        jPane.add(titleLabe3,c);  
        c.gridx=2;
        c.gridy=2; 
        jPane.add(titleText3,c);    
        

        //������
        JLabel titleLabe4 = new JLabel("�ϴ��ڵ㣺");
        JLabel titleText4 = new JLabel(prpLImageShow.getNodeType());  
        c.gridx=1;
        c.gridy=3; 
        jPane.add(titleLabe4,c);  
        c.gridx=2;
        c.gridy=3; 
        jPane.add(titleText4,c);   
        

        //������
        JLabel titleLabe5 = new JLabel("ͼƬ˵����");
        titleText5.setText(prpLImageShow.getDisPlayName());
        titleText5.setAutoscrolls(true);
        titleText5.setColumns(4);
        c.gridx=1;
        c.gridy=4; 
        jPane.add(titleLabe5,c);  
        c.gridx=2;
        c.gridy=4; 
        jPane.add(titleText5,c);  
        prpLImageShow.setDisPlayName(titleText5.getText());
        c.fill=GridBagConstraints.NONE;
        JButton uploadButton2 = new JButton("����"); 
        c.gridx=1;  
        c.gridy=5; 
        //���������¼�
        prpLImageShow.setWebUrl(prpLImageDto.getWebUrl());
		
        uploadButton2.addActionListener(new ImageUpdateListener(this,titleText5.getText(),prpLImageShow));
        jPane.add(uploadButton2,c);
        
        //�ر�
        JButton closeButton = new JButton("�ر�");
        c.gridx = 2;  
        c.gridy = 5; 
        closeButton.addActionListener(new ActionListener(){
        	public void actionPerformed(ActionEvent e){ 
        		setInvisi();
        	}   
        });
        jPane.add(closeButton, c);          
        
        jPane.setSize(200,100);
        ContentPane.add(jPane,BorderLayout.CENTER);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }  

    /**
	 * @param objects
	 */
	private void addElement(Object[] objects) {
		// TODO Auto-generated method stub
		
	}

	public void setInvisi(){
    	this.setVisible(false);
    }


    /**
     * ͼ����¼����� 
     */
    public class ImageUpdateListener implements ActionListener {
    	private PrpLImageDto prpLImageDto;
        private Component parentWindow;
        private String textVlaue;
        ImagePreviewer previewer = new ImagePreviewer();
        public ImageUpdateListener(Component parent, String textVlaue,
        		                   PrpLImageDto prpLImageDtoTemp) {
            this.parentWindow = parent;
            this.prpLImageDto = prpLImageDtoTemp;           
            this.textVlaue = textVlaue; 
         
        }
     
        public void actionPerformed(ActionEvent e) {
            Runnable upload = new Runnable() { 
                public void run() { 
                  try {     
                    //�޸����ݿ��еĶ���
                    UIServerFacade UIServerFacade= new UIServerFacade();
                    prpLImageDto.setDisPlayName(titleText5.getText());
                    //����xml�ļ� 
                  	String xmlData = UIServerFacade.generateXMLHead(prpLImageDto,"update");
                  	xmlData+=UIServerFacade.generateXMLBody(prpLImageDto,"update");
                  	xmlData+=UIServerFacade.generateXMLTail(prpLImageDto,"update");
                  	String saveFlag = UIServerFacade.sendDataToServer(prpLImageDto,xmlData);
                      
                    if(("true").equals(saveFlag)){
                       JOptionPane.showMessageDialog(null, "�޸ĳɹ�"); 
                    } else {
                       JOptionPane.showMessageDialog(null, "�޸�ʧ��"); 
                    }   
                    parentWindow.setCursor(Cursor .getPredefinedCursor(Cursor.DEFAULT_CURSOR));
                    parentWindow.setVisible(false);
                  }catch(Exception ex){
                  	ex.printStackTrace();
                  }   
                } 
              }; 
             
              SwingUtilities.invokeLater(upload);
        }
    }
	
}
 
