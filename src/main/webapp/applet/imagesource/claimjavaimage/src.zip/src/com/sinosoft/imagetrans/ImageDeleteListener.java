package com.sinosoft.imagetrans;

import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import com.sinosoft.claim.dto.custom.PrpLImageDto;
import com.sinosoft.sysframework.image.*;
import com.sinosoft.sysframework.transfer.FtpClient;
/**
 * ͼ��ɾ��������
 */
public class ImageDeleteListener implements ActionListener {
    private PrpLImageDto prpLImageDto;
    private Component parentWindow;
    private String remoteDir;
    private JFileChooser chooser = null;
    private JList list = null;
    private FtpClient ftpClient = null;
    ImagePreviewer previewer = new ImagePreviewer();
    public ImageDeleteListener(Component parent, FtpClient ftpClient, PrpLImageDto prpLImageDto, String remoteDir,
            JList list) {
        this.parentWindow = parent;
        this.ftpClient = ftpClient;
        this.remoteDir = remoteDir;
        this.list = list;
        this.prpLImageDto = prpLImageDto;
        /** ******************************* */
        //confirmFtp();
        /** ******************************* */
    }

    public void actionPerformed(ActionEvent e) {
        Runnable upload = new Runnable() {
            public void run() {
                try {
                    parentWindow.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
                    ImageFileListModel model = (ImageFileListModel) list.getModel();
                    int intSelect = list.getSelectedIndex();
//                    System.out.println("----intSelect-----:" + intSelect);
                    if (intSelect == -1) {
                        JOptionPane.showMessageDialog(null, "��ѡ��Ҫɾ����ͼƬ");
                    } else {
                        String fileName = model.getFileName(model.getElementAt(intSelect));
                        String fileDeleteName = fileName.substring(fileName.lastIndexOf("R"));
//                        System.out.println("----fileDelete---" + fileDeleteName + prpLImageDto.getRegistNo());
                        ftpClient.mkdirs(remoteDir);
                        ftpClient.cd(remoteDir);
                        int countDelete = ftpClient.rm(fileDeleteName);//ɾ���ļ�
                        //ɾ�����ݿ��еĶ���
                        UIServerFacade UIServerFacade = new UIServerFacade();

                        //����xml�ļ�
                        prpLImageDto.setImgFileName(fileDeleteName);
                        String xmlData = UIServerFacade.generateXMLHead(prpLImageDto, "delete");
                        xmlData += UIServerFacade.generateXMLBody(prpLImageDto, "delete");
                        xmlData += UIServerFacade.generateXMLTail(prpLImageDto, "delete");
                        String saveFlag = UIServerFacade.sendDataToServer(prpLImageDto, xmlData);
                        System.out.println("---countDelete------" + countDelete + "|" + saveFlag);
                        if (countDelete == 250) {
                            JOptionPane.showMessageDialog(null, "ɾ���ļ�" + fileDeleteName + "�ɹ�");
                            parentWindow.repaint();
                        }
                        parentWindow.repaint();
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }

                try {
                    ((FtpImageFileListModel) list.getModel()).refresh();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
                parentWindow.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));

            }
        };

        SwingUtilities.invokeLater(upload);
    }
}