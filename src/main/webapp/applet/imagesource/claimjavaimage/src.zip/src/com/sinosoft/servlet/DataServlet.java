/*
 * Created on 2005-3-31
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.sinosoft.servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*; 

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class DataServlet extends HttpServlet
{
    public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        int resultCode = 0;
        String errorMsg = "ok";

        BufferedInputStream inStream = new BufferedInputStream(request.getInputStream());
        ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
        byte[] b = new byte[1024];
        int read = 0;
        byte[] xmlData = null;
        try {
            while ((read = inStream.read(b)) > 0) {
                byteOut.write(b, 0, read);
            }
            xmlData = byteOut.toByteArray();
        }
        catch(IOException ex) {
            resultCode = ex.hashCode(); //just for test
            errorMsg = ex.getMessage();  //just for test
            ex.printStackTrace();
        }
        finally {
            byteOut.close();
            inStream.close();
        }
//        System.out.println(xmlData);
//        System.out.println(new String(xmlData));
        DataOutputStream outStream = new DataOutputStream(response.getOutputStream());
        outStream.writeInt(resultCode);
        outStream.writeUTF(errorMsg);
        outStream.close();
    }

}
