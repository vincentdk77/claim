package com.sinosoft.imagetrans;
import java.io.File;
import com.sinosoft.sysframework.common.util.StringUtils;
import com.sinosoft.sysframework.transfer.FtpFile;
/**
 * ͼ���乤����
 */
public class ImageTransUtils {
    private static final String cachePath = System
            .getProperty("java.io.tmpdir");
    /**
     * ��ֹʵ����
     */
    private ImageTransUtils() {
    }
    /**
     * ��ȡ���ػ���ͼƬ�ļ�
     * 
     * @param ftpFile ftpFile
     * @return ���ػ���ͼƬ�ļ�
     */
    public static File getCacheFile(FtpFile ftpFile) {
        String cacheFileName = "localCache" + ftpFile.getModifyDate();
        cacheFileName = StringUtils.replace(cacheFileName, " ", "");
        cacheFileName = StringUtils.replace(cacheFileName, ":", "");
        cacheFileName = StringUtils.replace(cacheFileName, ".", "");
        cacheFileName = cacheFileName + ftpFile.getFileName();
        File cacheFile = new File(cachePath, cacheFileName);
        return cacheFile;
    }
    /**
     * ��ȡ���ػ���ͼƬ�ļ�������ͼ�ļ�
     * 
     * @param ftpFile ftpFile
     * @return ���ػ���ͼƬ�ļ�������ͼ�ļ�
     */
    public static File getCacheOverviewFile(FtpFile ftpFile) {
        String cacheFileName = "localCacheOverview" + ftpFile.getModifyDate();
        cacheFileName = StringUtils.replace(cacheFileName, " ", "");
        cacheFileName = StringUtils.replace(cacheFileName, ":", "");
        cacheFileName = StringUtils.replace(cacheFileName, ".", "");
        cacheFileName = cacheFileName + ftpFile.getFileName();
        File cacheOverviewFile = new File(cachePath, cacheFileName);
        return cacheOverviewFile;
    }
}
