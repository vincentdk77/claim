package com.sinosoft.imagetrans;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Arrays;
import java.util.Comparator;

import javax.swing.ImageIcon;

import com.sinosoft.sysframework.image.ImageFileListModel;
import com.sinosoft.sysframework.image.JPEGFile;
import com.sinosoft.sysframework.transfer.FtpClient;
import com.sinosoft.sysframework.transfer.FtpFile;
/**
 * �б���ʾͼƬ
 */
public class FtpImageFileListModel extends ImageFileListModel {
    private FtpClient ftpClient;
    private String remoteDir;
    /**
     * @throws Exception
     */
    public FtpImageFileListModel(FtpClient ftpClient, String remoteDir)
            throws Exception {
        this.ftpClient = ftpClient;
        this.remoteDir = remoteDir;
        refresh();
    } 
      
    /**
     * ˢ��
     * 
     * @throws Exception
     */
    public void refresh() throws Exception {
        removeAllElements();
        FtpFile[] ftpFiles = ftpClient.getFileList(remoteDir);
        // ���ļ�ʱ������
        Arrays.sort(ftpFiles, new Comparator() {
            public int compare(Object o1, Object o2) {
                FtpFile f1 = (FtpFile) o1;
                FtpFile f2 = (FtpFile) o2;

                return f1.getModifyDate().compareTo(f2.getModifyDate());
            }
        });
        for (int i = 0; i < ftpFiles.length; i++) {
            FtpFile ftpFile = ftpFiles[i];
            if (ftpFile.isDir() == true) {//�����Ŀ¼�����
                continue;
            }
            File cacheFile = ImageTransUtils.getCacheFile(ftpFile);
            if (!cacheFile.exists()) {//�����ڻ����ļ�������
                ftpClient.get(remoteDir + "/" + ftpFile.getFileName(),
                        cacheFile.getPath());
            }
            File overviewFile = ImageTransUtils.getCacheOverviewFile(ftpFile);
            if (!overviewFile.exists()) {//�����ڻ����ļ�������ͼ�ļ������¹�������ͼ
                JPEGFile jpegFile = new JPEGFile(cacheFile.getPath());
                FileOutputStream out = new FileOutputStream(overviewFile);
                jpegFile.encode(JPEGFile.SCALE_BASE_Y, 50, 0.75, out);
                out.close();
            } 
            ImageIcon imageIcon =new ImageIcon(overviewFile.getPath());
            addElement(new Object[]{ftpFile.getFileName(),imageIcon, cacheFile.getPath()});
            
        }
    }
}
