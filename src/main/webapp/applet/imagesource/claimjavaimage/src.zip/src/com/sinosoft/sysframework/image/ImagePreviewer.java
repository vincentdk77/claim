/**
 * @author lijiyuan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * Author:Mr.Li    lijiyuan create version  1.0 
 */

package com.sinosoft.sysframework.image;
import java.awt.*;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
/**
 * ͼ��Ԥ����
 */
public class ImagePreviewer extends JComponent {
    private ImageIcon icon;
    public void update(File file) {
        if (file != null) { 
            Dimension size = getSize();
            Insets insets = getInsets();
            icon = new ImageIcon(file.getPath());
            icon.setImage(icon.getImage().getScaledInstance(
                    size.width - insets.left - insets.right,
                    size.height - insets.top - insets.bottom,
                    Image.SCALE_SMOOTH));
            if (isShowing()) {
                repaint();
            }
        }
    }
    public void paintComponent(Graphics g) {
        Insets insets = getInsets();
        super.paintComponent(g);
        if (icon != null) {
            icon.paintIcon(this, g, insets.left, insets.top);
        }
    }
}
