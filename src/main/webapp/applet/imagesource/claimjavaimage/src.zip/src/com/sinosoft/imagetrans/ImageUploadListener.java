/**
 * @author lijiyuan
 * Author:Mr.Li    lijiyuan create version  1.0 
 */

package com.sinosoft.imagetrans;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileFilter;

import com.sinosoft.claim.dto.custom.PrpLImageDto;
import com.sinosoft.sysframework.common.util.FileUtils;
import com.sinosoft.sysframework.image.ImagePreviewer;
import com.sinosoft.sysframework.image.ImagePreviewerAccessoryAdapter;
import com.sinosoft.sysframework.image.JPEGFile;
import com.sinosoft.sysframework.transfer.HttpClient;

/**
 * ͼ���ϴ�������
 */
public class ImageUploadListener implements ActionListener {

	private PrpLImageDto prpLImageDto;

	private int maxImageWidth;

	private double compressionQuality;

	private Component parent;

	private JFileChooser chooser = null;

	private JCheckBox check = null;

	private JList list = null;

	private HttpClient httpClient = null;

	ImagePreviewer previewer = new ImagePreviewer();

	public ImageUploadListener(Component parent, HttpClient ftpClient, PrpLImageDto prpLImageDto, int maxImageWidth,
			double compressionQuality, JCheckBox check, JList list) {
		this.parent = parent;
		this.httpClient = ftpClient;
		this.maxImageWidth = maxImageWidth;
		this.compressionQuality = compressionQuality;
		this.check = check;
		this.list = list;
		this.prpLImageDto = prpLImageDto;
		confirmChooser();
	}

	private void setAccessoryComponent() {
		JPanel previewPanel = new JPanel();
		previewPanel.setLayout(new BorderLayout());
		previewPanel.add(new JLabel("Ԥ��", SwingConstants.CENTER), BorderLayout.NORTH);
		previewPanel.add(previewer, BorderLayout.CENTER);
		previewer.setPreferredSize(new Dimension(200, 0));
		previewer.setBorder(BorderFactory.createEtchedBorder());
		chooser.setAccessory(previewPanel);
		new ImagePreviewerAccessoryAdapter(chooser, previewer);
	}

	/**
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e) {
		int state = chooser.showDialog(parent, "�ϴ�");

		if (chooser.getSelectedFiles() == null || chooser.getSelectedFiles().length == 0
				|| state != JFileChooser.APPROVE_OPTION) {
			return;
		}
		Runnable upload = new Runnable() {
			public void run() {
				int intFilesLenght = chooser.getSelectedFiles().length; //ѡ���ͼƬ����
				try {
					parent.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
					final int PICCOUNT_SIZE = 1540; //�ϴ�ͼƬ��С���Ϊ1540K  
					double lngPicSize = 0.0D;

					//Modify by wangwei update start 2005-12-29
					//Reason: �����ж��ļ������͵����ļ���С��ֻ���ж�һ���ϴ��ļ����ܴ�С��
					//		      if (intFilesLenght > prpLImageDto.getImgFileCount()) {
					//                   JOptionPane.showMessageDialog(null, "���ֻ��ѡ��"+String.valueOf(prpLImageDto.getImgFileCount())
					//                                   +"���ļ�","��ʾ��Ϣ",JOptionPane.INFORMATION_MESSAGE);
					//	               parent.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));					  
					//                   return;
					//		      }

					//			long fileSizelimit  =prpLImageDto.getImgFileCapabillity()/ 1024L;

					for (int j = 0; j < intFilesLenght; j++) {
						File file = new File(chooser.getSelectedFiles()[j].getAbsolutePath());
						long fileSize = file.length();
						prpLImageDto.setImgSize(fileSize); //����ͼƬ��С����  2005-12-12
						lngPicSize = lngPicSize + fileSize / 1024L;
					}


					if (lngPicSize > PICCOUNT_SIZE) {
						JOptionPane.showMessageDialog(null, "һ���ϴ��ļ��Ĵ�С���ܳ���" + PICCOUNT_SIZE + "K", "��ʾ��Ϣ",
								JOptionPane.INFORMATION_MESSAGE);
						parent.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
						return;
					}
					//Modify by wangwei update end 2005-12-29
					String tmpdir=chooser.getSelectedFiles()[0].getAbsolutePath();
				    confirmFile(tmpdir.substring(0,tmpdir.lastIndexOf('\\')));
					
					String[] remoteFiles = new String[intFilesLenght];
					String[] filename = new String[intFilesLenght];

					UIServerFacade UIServerFacade = new UIServerFacade();
					//UIUploadFileProcessFacade uiUploadFileProcessFacade = new UIUploadFileProcessFacade();
					//ƴ��XML�ļ�   
					String[] xmlDatas = new String[intFilesLenght];
					for (int i = 0; i < intFilesLenght; i++) {
						xmlDatas[i] = UIServerFacade.generateXMLHead(prpLImageDto, "insert");
						remoteFiles[i] = "#" + FileUtils.getFileNameExt(chooser.getSelectedFiles()[i].getPath());
						filename[i] = prpLImageDto.getRegistNo() + prpLImageDto.getTypeCode() + prpLImageDto.getLossItemCode();
						//prpLImageDto.setImgFileName(remoteFiles[i]);
						prpLImageDto.setPicPath(prpLImageDto.getFtpSavePath());
						prpLImageDto.setImgFileName(remoteFiles[i]);
						prpLImageDto.setUploadFileName(FileUtils.getShortFileName(chooser.getSelectedFiles()[i]
								.getPath()));
						prpLImageDto.setDisPlayName(prpLImageDto.getUploadFileName());
						xmlDatas[i] += UIServerFacade.generateXMLBody(prpLImageDto, "insert");
						xmlDatas[i] += UIServerFacade.generateXMLTail(prpLImageDto, "insert");
					}

					String[] localFiles = new String[intFilesLenght];
					String tempPath = System.getProperty("java.io.tmpdir");
					if (check.isSelected()) {
						for (int i = 0; i < intFilesLenght; i++) {
							String fileExt = FileUtils.getFileNameExt(chooser.getSelectedFiles()[i].getPath())
									.toLowerCase();
							if (".gif".equals(fileExt) || ".jpg".equals(fileExt) || ".jpeg".equals(fileExt)) {
								JPEGFile jpegFile = new JPEGFile(chooser.getSelectedFiles()[i].getPath());
								File newFile = new File(tempPath, i + remoteFiles[i]);
								FileOutputStream out = new FileOutputStream(newFile);
								jpegFile.encode(JPEGFile.SCALE_BASE_X, maxImageWidth, compressionQuality, out);
								out.close();
								localFiles[i] = newFile.getPath();
							} else {
								localFiles[i] = chooser.getSelectedFiles()[i].getPath();
							}
						}
					} else {
						for (int i = 0; i < intFilesLenght; i++) {
							localFiles[i] = chooser.getSelectedFiles()[i].getPath();
						}
					}

					httpClient.mkdirs("/dubang/" + prpLImageDto.getFtpSavePath());
					httpClient.cd("/dubang/" + prpLImageDto.getFtpSavePath());

					//�ϴ�ͼƬ�����ݿ��prplcertifyimg���б�������
					httpClient.mput(localFiles, remoteFiles, xmlDatas, filename);
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null, e1.getMessage());
					e1.printStackTrace();
				}

				try {
					//                   if (JOptionPane.showConfirmDialog(new JFrame(),
					//                           intFilesLenght + "���ļ��ϴ��ɹ�������鿴��", "��ʾ��Ϣ",
					//                           JOptionPane.YES_NO_OPTION) == JOptionPane.NO_OPTION) {  //���������ʾͼƬ
					JOptionPane.showMessageDialog(null, intFilesLenght + "���ļ��ϴ��ɹ�", "��ʾ��Ϣ",JOptionPane.INFORMATION_MESSAGE);
					HttpClient httpClient1 = new HttpClient();
					ArrayList collectionhttp = httpClient1.getcollect(prpLImageDto);
					httpClient1.mget(collectionhttp);
					String typecode = prpLImageDto.getTypeCode();
					((HttpImageFileListModel) list.getModel()).setTypeCode(typecode);
					((HttpImageFileListModel) list.getModel()).setCollection(collectionhttp);
					((HttpImageFileListModel) list.getModel()).refresh();
					//                   }
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				parent.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
			}
		};

		SwingUtilities.invokeLater(upload);
	}

	private void confirmChooser() {
		if (chooser == null) {
			chooser = new JFileChooser();
			chooser.setCurrentDirectory(new File(confirmPath()));
			chooser.setMultiSelectionEnabled(true);
			setAccessoryComponent();
			//��һ��������
			chooser.addChoosableFileFilter(new FileFilter() {
				public boolean accept(File f) {
					String fileExt = FileUtils.getFileNameExt(f.getPath()).toLowerCase();
					if (f.isDirectory() || fileExt.equals(".doc")) {
						return true;
					}
					return false;
				}

				public String getDescription() {
					return "Word �ĵ���*.doc��";
				}
			});
			//�ڶ���������
			chooser.addChoosableFileFilter(new FileFilter() {
				public boolean accept(File f) {
					String fileExt = FileUtils.getFileNameExt(f.getPath()).toLowerCase();
					if (f.isDirectory() || fileExt.equals(".jpg") || fileExt.equals(".jpeg") || fileExt.equals(".gif")) {
						return true;
					}
					return false;
				}

				public String getDescription() {
					return "ͼƬ�ļ� ��ʽ��*.jpg;*.jpeg;*.gif��";
				}
			});
			chooser.setAcceptAllFileFilterUsed(false);
		}
	}
	 private String confirmPath() {
			String strPath="C:\\Documents and Settings\\Administrator\\My Documents\\pic";
			String str = "";
			try{
		       String tempPath = System.getProperty("java.io.tmpdir");
			tempPath = tempPath +"\\certifyconfig.txt";
			BufferedReader bw = new BufferedReader(new FileReader(new File(tempPath)));
			while((str=bw.readLine())!=null)
			{
			System.err.println("str:  "+str);
			strPath=str;
			}
			bw.close();
			}
			catch(IOException e)
			{
			e.printStackTrace();
			}
		 	return strPath;
		    }   
	 private String confirmFile(String dir) {
			String str = "";
		       String tempPath = System.getProperty("java.io.tmpdir");
			File f=new File(tempPath ,"certifyconfig.txt");
			tempPath = tempPath +"certifyconfig.txt";	
				try{
				BufferedWriter bw = new BufferedWriter(new FileWriter(new File(tempPath)));
				bw.write(dir);
				bw.flush();
				bw.close();
				}
				catch(IOException e)
				{
				e.printStackTrace();
				}				
			return str;
	}
}
