package com.sinosoft.sysframework.dto;

import java.io.Serializable;
/**
 * ����PrpLImageDtoͼƬ��Ϣ�����ݴ���������<br>
 * ������ 2004-4-5 15:33:39<br>
 */
public class PrpLImageDto {
  private int      maxImageWidth;             //���� 600
  private int      maxImageHeight;            //�߶�    400
  private String   certiType ;             //��֤���  7
  private String   lossItemCode ;          //��Ĵ��룬��Ϊ1��2��3��������Ϊ0
  private String   lossItemName ;          //�������
  private String   uploadYear ;            //���
  private String   riskCode ;              //����
  private String   nodeType ;              //�ϴ��ڵ����� certi
  private String   registNo ;              //��������    R4493050005010500002
  private double   compressionQuality;     //ѹ������  0.75
  private String   typeCode;               //��֤���ͻ�ͼƬ����   7001
  private String   typeName;              //��֤���ͻ�ͼƬ����   7001
  private String   uploadFileName ;        //�ϴ�ʱ�ļ���
  private String   collectorName;          //�ռ���
  private double   imgSize;                //�ϴ�ͼƬ�ֽ�����С
  private String   ftpSavePath;            //ftp�����·��
  private String   disPlayName;           //��ʾ��remark
  private String   imgFileName;           //imgFileNamek
  private String   SignInDate;           //imgFileNamek
  private String   picPath;           //imgFileNamek

	/**
	 * @return Returns the certiType.
	 */
	public String getCertiType() {
		return certiType;
	}
	/**
	 * @param certiType The certiType to set.
	 */
	public void setCertiType(String certiType) {
		this.certiType = certiType;
	}
	/**
	 * @return Returns the collectorName.
	 */
	public String getCollectorName() {
		return collectorName;
	}
	/**
	 * @param collectorName The collectorName to set.
	 */
	public void setCollectorName(String collectorName) {
		this.collectorName = collectorName;
	}
	/**
	 * @return Returns the compressionQuality.
	 */
	public double getCompressionQuality() {
		return compressionQuality;
	}
	/**
	 * @param compressionQuality The compressionQuality to set.
	 */
	public void setCompressionQuality(double compressionQuality) {
		this.compressionQuality = compressionQuality;
	}
	/**
	 * @return Returns the imgSize.
	 */
	public double getImgSize() {
		return imgSize;
	}
	/**
	 * @param imgSize The imgSize to set.
	 */
	public void setImgSize(double imgSize) {
		this.imgSize = imgSize;
	}
	/**
	 * @return Returns the lossItemCode.
	 */
	public String getLossItemCode() {
		return lossItemCode;
	}
	/**
	 * @param lossItemCode The lossItemCode to set.
	 */
	public void setLossItemCode(String lossItemCode) {
		this.lossItemCode = lossItemCode;
	}
	/**
	 * @return Returns the maxImageHeight.
	 */
	public int getMaxImageHeight() {
		return maxImageHeight;
	}
	/**
	 * @param maxImageHeight The maxImageHeight to set.
	 */
	public void setMaxImageHeight(int maxImageHeight) {
		this.maxImageHeight = maxImageHeight;
	}
	/**
	 * @return Returns the maxImageWidth.
	 */
	public int getMaxImageWidth() {
		return maxImageWidth;
	}
	/**
	 * @param maxImageWidth The maxImageWidth to set.
	 */
	public void setMaxImageWidth(int maxImageWidth) {
		this.maxImageWidth = maxImageWidth;
	}
	/**
	 * @return Returns the nodeType.
	 */
	public String getNodeType() {
		return nodeType;
	}
	/**
	 * @param nodeType The nodeType to set.
	 */
	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}
	/**
	 * @return Returns the registNo.
	 */
	public String getRegistNo() {
		return registNo;
	}
	/**
	 * @param registNo The registNo to set.
	 */
	public void setRegistNo(String registNo) {
		this.registNo = registNo;
	}
	/**
	 * @return Returns the typeCode.
	 */
	public String getTypeCode() {
		return typeCode;
	}
	/**
	 * @param typeCode The typeCode to set.
	 */
	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}
	/**
	 * @return Returns the uploadFileName.
	 */
	public String getUploadFileName() {
		return uploadFileName;
	}
	/**
	 * @param uploadFileName The uploadFileName to set.
	 */
	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}
/**
 * @return Returns the ftpSavePath.
 */
public String getFtpSavePath() {
	return ftpSavePath;
}
/**
 * @param ftpSavePath The ftpSavePath to set.
 */
public void setFtpSavePath(String ftpSavePath) {
	this.ftpSavePath = ftpSavePath;
}
/**
 * @return Returns the disPlayName.
 */
public String getDisPlayName() {
	return disPlayName;
}
/**
 * @param disPlayName The disPlayName to set.
 */
public void setDisPlayName(String disPlayName) {
	this.disPlayName = disPlayName;
}
/**
 * @return Returns the imgFileName.
 */
public String getImgFileName() {
	return imgFileName;
}
/**
 * @param imgFileName The imgFileName to set.
 */
public void setImgFileName(String imgFileName) {
	this.imgFileName = imgFileName;
}
/**
 * @return Returns the lossItemName.
 */
public String getLossItemName() {
	return lossItemName;
}
/**
 * @param lossItemName The lossItemName to set.
 */
public void setLossItemName(String lossItemName) {
	this.lossItemName = lossItemName;
}
/**
 * @return Returns the riskCode.
 */
public String getRiskCode() {
	return riskCode;
}
/**
 * @param riskCode The riskCode to set.
 */
public void setRiskCode(String riskCode) {
	this.riskCode = riskCode;
}
/**
 * @return Returns the uploadYear.
 */
public String getUploadYear() {
	return uploadYear;
}
/**
 * @param uploadYear The uploadYear to set.
 */
public void setUploadYear(String uploadYear) {
	this.uploadYear = uploadYear;
}
/**
 * @return Returns the typeName.
 */
public String getTypeName() {
	return typeName;
}
/**
 * @param typeName The typeName to set.
 */
public void setTypeName(String typeName) {
	this.typeName = typeName;
}
/**
 * @return Returns the signInDate.
 */
public String getSignInDate() {
	return SignInDate;
}
/**
 * @param signInDate The signInDate to set.
 */
public void setSignInDate(String signInDate) {
	SignInDate = signInDate;
}
/**
 * @return Returns the picPath.
 */
public String getPicPath() {
	return picPath;
}
/**
 * @param picPath The picPath to set.
 */
public void setPicPath(String picPath) {
	this.picPath = picPath;
}
}
