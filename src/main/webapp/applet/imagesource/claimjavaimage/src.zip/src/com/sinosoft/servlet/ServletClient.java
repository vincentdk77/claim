/*
 * Created on 2005-3-31
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.sinosoft.servlet;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import java.io.*;
import java.net.*;

public class ServletClient
{

    private static String SERVER_URL = "http://picctest.ebao.com/autoclaim/servlet/com.ebao.autoclaim.datachange.ccic.DataChangeServlet";

    public ServletClient()
    {
    }


    /**
     * send data
     * @param data String data
     * @throws IOException
     * @throws MalformedURLException
     * @throws ConnectException
     * @return String result code
     */
    private void sendData(String data) throws IOException, MalformedURLException, ConnectException
    {
        int resultCode = -1;
        String resultDesc = null;
        URL uploadServlet = new URL(SERVER_URL);
        URLConnection servletConnection = uploadServlet.openConnection();
        servletConnection.setDoOutput(true);

        BufferedOutputStream output = new BufferedOutputStream(servletConnection.getOutputStream());
        output.write(data.getBytes());
        output.close();

        DataInputStream input = new DataInputStream(servletConnection.getInputStream());
        resultCode = input.readInt();
        resultDesc = input.readUTF();
        input.close();
    }


    public static void main(String[] args)
    {
        ServletClient servletClient1 = new ServletClient();
        try {
        	String dataXML = "<?xml version='1.0' encoding='GB2312'?><carcase for='DATACHANGE' version='1.2'><head><creator>�п��� �����Ʒ��</creator><create_time>2004-05-17 14:29:50</create_time></head><body><company_id>CCIC_BJ</company_id><report_info>                          <report_id>R4493050005010500002</report_id><claim_type>1</claim_type><report_time>2004-02-12 9:6:00</report_time><damage_time>2004-02-09 15:45:00</damage_time><reportor_name>������</reportor_name><contact_person>������</contact_person><reportor_telephone>13801732835</reportor_telephone><damage_place>�ϻ�����ף�Ҹ�·</damage_place><accident_code>456</accident_code><accident_cause>��ײ</accident_cause><accident_detail>2��12�սӱ����绰������2��9�����类���ձ�ĳ�����A11102���ϻ�����ף�Ҹ�·����������ⲻ����һ���ֳ���ײ��ɱ����Һ������</accident_detail><report_mode>01</report_mode><is_first_locale>0</is_first_locale><deal_department>3</deal_department><deal_department_name>�Ϻ��ֹ�˾�ͻ�����</deal_department_name><remark></remark><acceptor_code>report</acceptor_code></report_info><policy_info><policy_id></policy_id><insured_product_code>0501</insured_product_code><company_id>31010062</company_id><company_name>�Ϻ��ֹ�˾Ӫҵ����</company_name><policy_from>1</policy_from><start_time>2004-01-07 0:00:00</start_time><end_time>2005-01-06 24:00:00</end_time><insured><insured_name>�Ϻ��Ź������������޹�˾</insured_name></insured><car_value>110000.0</car_value><car_category>�ͳ�</car_category><car_type>ɣ����330K8BLOLSD1</car_type><car_mark>��A11102</car_mark><mark_color>��</mark_color><vin_code></vin_code><engine_no>217483</engine_no><rack_no>NW301599</rack_no><seats>5</seats><carrying_capacity>0.0</carrying_capacity><register_date>1992-06-01 00:00:00</register_date><use_kind>��Ӫҵ��(������ͥ����)</use_kind><drive_area>�л����񹲺͹�����(�����۰�̨)</drive_area><assumpsit></assumpsit><premium_is_paid>1</premium_is_paid><insure_type_list><insure_type><id>A</id><name>������ʧ��</name><value>0</value><excess_amount>0</excess_amount><excess_rate>0</excess_rate></insure_type><insure_type><id>B</id><name>������������</name><value>0</value><excess_amount>0</excess_amount><excess_rate>0</excess_rate></insure_type><insure_type><id>M</id><name>����������Լ</name><value>0</value><excess_amount>0</excess_amount><excess_rate>0</excess_rate></insure_type></insure_type_list></policy_info><dispatch_info_list><dispatch_info><damage_type>1</damage_type><dispatcher>charlie</dispatcher><object_name>��A11102</object_name><surveyor>charlie</surveyor><insured_mark>1</insured_mark><remark>������Ϣ</remark></dispatch_info></dispatch_info_list></body></carcase>";
            servletClient1.sendData(dataXML);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }

}
