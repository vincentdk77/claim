/**
 * @author lijiyuan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * Author:Mr.Li    lijiyuan create version  1.0 
 */

package com.sinosoft.sysframework.image;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import javax.swing.JFileChooser;
/**
 * ͼ��Ԥ��������
 */
public class ImagePreviewerAccessoryAdapter {
    public ImagePreviewerAccessoryAdapter(JFileChooser chooser,
            final ImagePreviewer previewer) {
        chooser.addPropertyChangeListener(new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent e) {
                if (e.getPropertyName().equals(
                        JFileChooser.SELECTED_FILE_CHANGED_PROPERTY)) {
                    previewer.update((File) e.getNewValue());
                }
            }
        });
    }
}
 
