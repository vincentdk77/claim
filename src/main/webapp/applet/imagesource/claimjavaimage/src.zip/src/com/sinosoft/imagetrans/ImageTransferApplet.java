package com.sinosoft.imagetrans;

import java.awt.BorderLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import netscape.javascript.JSException;
import netscape.javascript.JSObject;
import com.sinosoft.claim.dto.custom.PrpLImageDto;
import com.sinosoft.sysframework.common.util.SwingUtils;

/**
 * @author lijiyuan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * Author:Mr.Li    lijiyuan create version  1.0 
 */
public class ImageTransferApplet extends JApplet {
    private PrpLImageDto prpLImageDto = new PrpLImageDto();	
    private int maxImageWidth;
    private double compressionQuality;
    private JButton start;
    private String uploadData;
    static {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception exc2) {
            try {
                UIManager.setLookAndFeel(UIManager
                        .getCrossPlatformLookAndFeelClassName());
            } catch (Exception e1) {
            }
            System.err.println("Error loading L&F: " + exc2);
        }
    }
    
    /**
     * @throws java.awt.HeadlessException
     */
    public ImageTransferApplet() throws HeadlessException {
        super();
        getContentPane().setLayout(new BorderLayout(5, 5));
        start = new JButton("Start ImageTranser");
        getContentPane().add(start, BorderLayout.CENTER);
        start.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                doStart();
            }
        });
    }
    
    public void init() {
        super.init();
        maxImageWidth = Integer.parseInt(getParameter("maxImageWidth"));
        compressionQuality = Double
                .parseDouble(getParameter("compressionQuality"));
    	this.prpLImageDto.setCertiType(getParameter("certiType"));
    	this.prpLImageDto.setLossItemCode(getParameter("lossItemCode"));
    	this.prpLImageDto.setLossItemName(getParameter("lossItemName")); 
    	this.prpLImageDto.setUploadYear(getParameter("uploadYear")); 
    	this.prpLImageDto.setRiskCode(getParameter("riskCode")); 
    	this.prpLImageDto.setNodeType(getParameter("nodeType")); 
    	this.prpLImageDto.setRegistNo(getParameter("registNo"));
    	this.prpLImageDto.setMaxImageWidth(Integer.parseInt(getParameter("maxImageWidth")) );
    	this.prpLImageDto.setMaxImageHeight(Integer.parseInt(getParameter("maxImageHeight")) );
    	this.prpLImageDto.setCompressionQuality(Double.parseDouble(getParameter("compressionQuality")) );
    	this.prpLImageDto.setCollectorName(getParameter("collectorName"));
    	this.prpLImageDto.setFtpPass(getParameter("ftpPass"));
    	this.prpLImageDto.setFtpUrl(getParameter("ftpUrl"));
    	this.prpLImageDto.setImgFileCount(Integer.parseInt(getParameter("imgFileCount")));
    	this.prpLImageDto.setImgFileCapabillity(Long.parseLong(getParameter("imgFileCapabillity")));
    	this.prpLImageDto.setFtpUser(getParameter("ftpUser")); 
    	this.prpLImageDto.setWebUrl(getParameter("webUrl"));
    	this.prpLImageDto.setStrImageTypeList(getParameter("strImageTypeList"));
    	this.prpLImageDto.setStrTitleList(getParameter("strTitleList"));
    	this.prpLImageDto.setImgUrl(getParameter("imgUrl"));
    	this.prpLImageDto.setPolicyNo(getParameter("PolicyNo"));  //���ӱ����� 2005-12-12
    	this.prpLImageDto.setSignInDate(getParameter("SignInDate"));                        //����ǩ������ 2006-02-10
    	System.err.println("��ʼ����Ϣ��init��webUrl������" + this.prpLImageDto.getWebUrl());	    
        doStart();
    }
    
    public void doStart() {
        ImageTransfer imageTransfer = new ImageTransfer(prpLImageDto, maxImageWidth,
                compressionQuality);
        imageTransfer.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        imageTransfer.pack();
        SwingUtils.center(imageTransfer);
        imageTransfer.setVisible(true);
    }
    
    public String getUploadData() {
        uploadData = "This is a test!";
        return uploadData;
    }
    
    public void msgbox(String message) {
        JSObject js;
        try {
            js = JSObject.getWindow(this);
            js.call("msgbox", new Object[]{message});
        } catch (JSException e) {
            e.printStackTrace();
        }
    }
}
