/**
 * @author lijiyuan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * Author:Mr.Li    lijiyuan create version  1.0 
 */

/*
 * Created on 2005-4-8
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.sinosoft.imagetrans;




import java.net.ConnectException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.io.*;
import java.io.ObjectOutputStream;
import java.net.HttpURLConnection;
import java.util.*;   
import com.sinosoft.sysframework.transfer.*;
import javax.swing.JOptionPane;
 
import com.sinosoft.claim.dto.custom.PrpLImageDto;
 
/**   
 * @author Administrator
 *  
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class UIServerFacade {
	/**
	 * ��web�������ύ����
	 * @param interMethod String
	 * @throws Exception
	 * @return String
	 */
    public String sendDataToServer(PrpLImageDto prpLImageDto,String xmlData) throws Exception
	{ 
		String SERVER_URL = prpLImageDto.getWebUrl();
		URL	url = new URL(SERVER_URL);
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		con.setDoOutput(true);
		con.setDoInput(true);
		con.setRequestMethod("POST");
		con.setUseCaches(false);
		con.setDefaultUseCaches(false);
		con.setRequestProperty("Content-Type", "application/octet-stream");
		con.connect();
		ObjectOutputStream out = new ObjectOutputStream(con.getOutputStream());
		try{		
		out.writeObject(new Integer(CommonClass.STEP4));
		out.writeObject(xmlData.getBytes());
		out.flush();
		out.close();
		}catch(ConnectException ex){
        	  JOptionPane.showMessageDialog(null, "���ӷ�����ʧ�ܣ�����ϵ����Ա");
			ex.printStackTrace();
		}

		try
		{
			ObjectInputStream is = new ObjectInputStream(con.getInputStream());
			ArrayList collection=(ArrayList) is.readObject();
			HttpImageFileListModel httpImageFileListModel = new HttpImageFileListModel();
			httpImageFileListModel .setCollection(collection);
	 		is.close();
		}
		catch (Exception e)
		{
			System.out.println("�����Ѿ����ͣ� ��û�з��ؽ����");
			e.printStackTrace();
			return "false";
		}
		return "true";
	}
 
	/**
	 * ����XMLͷ
	 * @param interMethod String
	 * @throws Exception
	 * @return String
	 */
	public String generateXMLHead(PrpLImageDto prpLImageDto,String method) throws Exception {
	      
	  String interMethod=method; 
	  String xmlData = "<?xml version=\"1.0\" encoding=\"gb2312\" standalone=\"yes\" ?>";
	  xmlData += "<ClaimData>";
      xmlData += "<Interface>" + interMethod + "</Interface>";
       return xmlData;
  }    
   
	/**
	 * ����XML��
	 * @param interMethod String
	 * @throws Exception
	 * @return String
	 */
	public String generateXMLBody(PrpLImageDto prpLImageDto,String method) throws Exception {
	
//      	Date date = new Date();	 	
//      	SimpleDateFormat bartDateFormat = new SimpleDateFormat("yyyy-MM-dd"); 	
//      	prpLImageDto.setSignInDate(bartDateFormat.format(date));

		String interMethod=method; 
        //��֯����   
	    String xmlData = "<" + method + ">";
        xmlData += "<businessNo>" + prpLImageDto.getRegistNo() + "</businessNo>";
        xmlData += "<lossItemCode>" + prpLImageDto.getLossItemCode() + "</lossItemCode>";
        xmlData += "<lossItemName>" + prpLImageDto.getLossItemName() + "</lossItemName>";
        xmlData += "<typeCode>" + prpLImageDto.getTypeCode() + "</typeCode>";
        xmlData += "<picName>" + prpLImageDto.getTypeName() + "</picName>";
        xmlData += "<signInDate>" + prpLImageDto.getSignInDate() + "</signInDate>";
        xmlData += "<thirdPartyCode>11111111</thirdPartyCode>"; 
        xmlData += "<uploadFileName>" + prpLImageDto.getUploadFileName() + "</uploadFileName>";
        xmlData += "<imgFileName>" + prpLImageDto.getImgFileName() + "</imgFileName>";
        xmlData += "<picPath>" + prpLImageDto.getPicPath() + "</picPath>";
        xmlData += "<collectorName>" + prpLImageDto.getCollectorName() + "</collectorName>";
        xmlData += "<receiveStatus>11</receiveStatus>";
        xmlData += "<flag>1</flag>"; 
        xmlData += "<imgSize>" + prpLImageDto.getImgSize() + "</imgSize>"; 
        xmlData += "<uploadNodeFlag>" + prpLImageDto.getNodeType() + "</uploadNodeFlag>";
        xmlData += "<displayName>" + prpLImageDto.getDisPlayName() + "</displayName>";
        xmlData += "<policyNo>"+ prpLImageDto.getPolicyNo() + "</policyNo>";
        xmlData += "</" + method + ">";
	  
       return xmlData;
  }    

	/**
	 * ����XMLβ
	 * @param interMethod String
	 * @throws Exception
	 * @return String
	 */
	public String generateXMLTail(PrpLImageDto prpLImageDto,String method) throws Exception {

	  String interMethod=method; 		
	  String xmlData= "</ClaimData>";
       return xmlData;
  }    
}
