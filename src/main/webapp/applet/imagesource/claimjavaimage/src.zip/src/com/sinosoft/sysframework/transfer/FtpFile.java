package com.sinosoft.sysframework.transfer;
import java.util.ArrayList;
import java.util.StringTokenizer;
/**
 * Զ�̷������ϵ�Ŀ¼
 */
public class FtpFile {
    private String fileName;
    private String fileSize;
    private String modifyDate;
    private boolean dir;
    /**
     * ���췽��
     * 
     * @param line ftp����������������Ϣ
     */
    public FtpFile(String line) {
        ArrayList info = parseLine(line);
        dir = ((String) info.get(0)).indexOf("d") != -1;
        if (info.size() > 8) {
            fileName = ((String) info.get(8));
        } else {
            fileName = "/";
        }
        fileSize = (String) info.get(4);
        modifyDate = (String) info.get(5) + " " + (String) info.get(6) + " "
                + (String) info.get(7);
    }
    //��������Ϣ
    private ArrayList parseLine(String line) {
        ArrayList s1 = new ArrayList();
        StringTokenizer st = new StringTokenizer(line, " ");
        while (st.hasMoreTokens()) {
            s1.add(st.nextToken());
        }
        return s1;
    }
    public boolean isDir() {
        return dir;
    }
    public String getFileName() {
        return fileName;
    }
    public String getFileSize() {
        return fileSize;
    }
    public String getModifyDate() {
        return modifyDate;
    }
    public String toString() {
        return fileName;
    }
}
