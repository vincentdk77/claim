/**
 * @author lijiyuan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * Author:Mr.Li    lijiyuan create version  1.0 
 */

package com.sinosoft.imagetrans;

import java.awt.Color;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.net.ConnectException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;
import javax.swing.ListCellRenderer;
import javax.swing.ListModel;
import javax.swing.SwingConstants;

import com.sinosoft.claim.dto.custom.PrpLImageDto;
import com.sinosoft.claim.dto.domain.PrpDcodeDto;
import com.sinosoft.sysframework.common.datatype.DateTime;
import com.sinosoft.sysframework.common.util.SwingUtils;
import com.sinosoft.sysframework.image.ImageFileListCellRenderer;
import com.sinosoft.sysframework.transfer.CommonClass;
import com.sinosoft.sysframework.transfer.ErrorCode;
import com.sinosoft.sysframework.transfer.HttpClient;

/**
 * ͼ����������
 */
public class ImageTransfer extends JFrame {

	Map certiTypeList = new HashMap();

	ArrayList imageTypeList = new ArrayList();

	private PrpLImageDto prpLImageDto = new PrpLImageDto();

	private PrpLImageDto prpLImageDtoTemp = new PrpLImageDto();

	private int maxImageWidth;

	private double compressionQuality;

	private static HttpClient httpClient = null;

	protected Action leftAction;

	protected Action middleAction;

	private String typecode = "";

	private ArrayList collectionhttp = new ArrayList();

	private JList list1 = null;

	public static void main(String[] args) {

		PrpLImageDto prpLImageDtoTemp = new PrpLImageDto();

		prpLImageDtoTemp.setCertiType("7");
		prpLImageDtoTemp.setLossItemCode("0");
		prpLImageDtoTemp.setNodeType("claim");
		prpLImageDtoTemp.setUploadYear("2005");
		prpLImageDtoTemp.setRiskCode("DAA");
		prpLImageDtoTemp.setLossItemName("claim");
		prpLImageDtoTemp.setRegistNo("R03070000050105000087");
		prpLImageDtoTemp.setMaxImageWidth(600);
		prpLImageDtoTemp.setMaxImageHeight(400);
		prpLImageDtoTemp.setCompressionQuality(0.75);
		prpLImageDtoTemp.setCollectorName("1101000022");
		prpLImageDtoTemp.setFtpUrl("10.2.71.31");
		prpLImageDtoTemp.setFtpUser("claim");
		prpLImageDtoTemp.setFtpPass("claim");
		prpLImageDtoTemp.setImgFileCount(5);
		prpLImageDtoTemp.setTypeCode("0101");
		prpLImageDtoTemp.setImgFileCapabillity(0x100000L);
		prpLImageDtoTemp.setWebUrl("http://192.168.62.11:7001/claim/certify");
		prpLImageDtoTemp.setImgUrl("http://192.168.62.11:7001/claim/images/splash.gif");
		prpLImageDtoTemp.setStrImageTypeList("0101�����������������������顷|");
		prpLImageDtoTemp.setStrTitleList("1��������|");
		prpLImageDtoTemp.setSignInDate(DateTime.current().toString());

		ImageTransfer imageTransfer = new ImageTransfer(prpLImageDtoTemp, 600, 0.75);
		imageTransfer.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		imageTransfer.pack();
		SwingUtils.center(imageTransfer);
		imageTransfer.setVisible(true);
	}

	private void confirmHttpClient(String webUrl) {
		if (httpClient != null) {
			return;
		}
		try {
			httpClient = new HttpClient(webUrl);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public ImageTransfer(PrpLImageDto prpLImageDto, int maxImageWidth, double compressionQuality) {
		super("Print Test");

		System.err.println(CommonClass.PRINT_STRING[0]);

		try {
			URL url = new URL(prpLImageDto.getImgUrl());
			SplashCertify.splash(url);
		} catch (Exception ConnectException) {
		}

		this.prpLImageDto = prpLImageDto;

		//��ʼ���б�����Ϣ
		setListData();

		//���ñ��� 
		if (prpLImageDto.getLossItemName() != null && prpLImageDto.getLossItemName().trim().equals("claim")) {
			this.setTitle((String) certiTypeList.get(prpLImageDto.getCertiType()) + "�ϴ�");
		} else {
			this.setTitle((String) certiTypeList.get(prpLImageDto.getCertiType()) + "("
					+ prpLImageDto.getLossItemName() + ")�ϴ�");
		}

		this.setTitle((String) certiTypeList.get("�ϴ�"));

		this.maxImageWidth = maxImageWidth;
		this.compressionQuality = compressionQuality;

		confirmHttpClient(prpLImageDto.getWebUrl());

		System.err.println(CommonClass.PRINT_STRING[1]);

		try {

			//�ϴ�ͼƬ�Ĺؼ�����
			createContent();

			SplashCertify.disposeSplash();
		} catch (NullPointerException nullEx) { //��ָ���쳣ʱ������Ϣ��ʾ
			JOptionPane.showMessageDialog(null, ErrorCode.ERROR_STRING[5]);
			SplashCertify.disposeSplash();
			this.dispose();
		} catch (ConnectException connEx) { //���������쳣
			JOptionPane.showMessageDialog(null, ErrorCode.ERROR_STRING[1]);
			SplashCertify.disposeSplash();
			this.dispose();
		} catch (java.io.IOException ioEx) { //I/O�쳣
			JOptionPane.showMessageDialog(null, ErrorCode.ERROR_STRING[6]);
			SplashCertify.disposeSplash();
			this.dispose();
		} catch (Exception ConnectException) { //�����쳣
			JOptionPane.showMessageDialog(null, ErrorCode.ERROR_STRING[7]);
			SplashCertify.disposeSplash();
			this.dispose();
		}
	}

	/**  
	 * ��ʼ����������
	 * @throws Exception
	 */

	private void setListData() {
		System.out.println(this.prpLImageDto.getStrTitleList());

		StringTokenizer st = new StringTokenizer(this.prpLImageDto.getStrTitleList(), "|");
		while (st.hasMoreTokens()) {
			String objcet = st.nextToken();
			this.certiTypeList.put(objcet.substring(0, 1), objcet.substring(1));
			System.out.println(CommonClass.PRINT_STRING[2] + objcet.substring(0, 1) + "|" + objcet.substring(1));
		}

		PrpDcodeDto prpDcodeDto = null;
		st = new StringTokenizer(this.prpLImageDto.getStrImageTypeList(), "|");
		while (st.hasMoreTokens()) {
			String objcet = st.nextToken();
			System.out.println(CommonClass.PRINT_STRING[3] + objcet.substring(0, 4) + "|" + objcet.substring(4));
			prpDcodeDto = new PrpDcodeDto();
			//         prpDcodeDto.setCodeCode(objcet.substring(0,4)); 
			//         prpDcodeDto.setCodeCName(objcet.substring(4));
			/**
			 * ����"@@"���ŷָ�typeCode��typeName
			 */
			String[] codeArray = objcet.split("@@");
			prpDcodeDto.setCodeCode(codeArray[0]);
			prpDcodeDto.setCodeCName(codeArray[1]);
			imageTypeList.add(prpDcodeDto);
		}
	}

	private void createContent() throws ConnectException, IOException, Exception {
		JToolBar toolBar = new JToolBar();
		JMenu mainMenu = new JMenu("��֤�ϴ�");
		createActionComponents(toolBar, mainMenu);

		ListCellRenderer renderer = new ImageFileListCellRenderer();
		Container contentPane = this.getContentPane();
		contentPane.setLayout(new GridBagLayout());
		contentPane.setForeground(Color.blue);

		//���ĸ�ʽ 
		GridBagConstraints c = new GridBagConstraints();
		c.fill = GridBagConstraints.BOTH;
		c.weightx = 100;
		c.weighty = 100;
		c.gridx = 0;
		c.gridy = 1;

		//JScrollPane  //�����Ĺ�����
		JScrollPane jScrollPaneFrame = new JScrollPane();

		//JPanel  //������������������(����) 
		JPanel jPaneFrame = new JPanel();
		jPaneFrame.setLayout(new GridBagLayout());

		contentPane.add(jScrollPaneFrame, c);

		c.gridx = 0;
		c.gridy = 1;
		c.fill = GridBagConstraints.NONE;
		jScrollPaneFrame.getViewport().add(jPaneFrame, c);
		c.fill = GridBagConstraints.NONE;

		//����     
		int serialNo = 0;

		HttpClient httpClientCollect = new HttpClient();

		//Modify by wangwei shield start 2006-02-10
		//Reason: ��֤�ϴ�ʱ��ʾ��ʽ���иı䡣�ڴ�Appletʱ����ʾͼƬ��
		//        �������ʾͼƬ����ťʱ����ʾ��Ӧ���͵�ͼƬ��
		try {

			//�õ�prplcertifyImg���е����ݣ�����������ͼƬ��Ϣ���ϡ�

			collectionhttp = httpClientCollect.getcollect(prpLImageDto);
			//�ѷ�������Ƭ���ص����ػ����ϣ����ж������Ƿ�������

			if (httpClientCollect.mget(collectionhttp) == CommonClass.RETURNTYPE) {
				JOptionPane.showMessageDialog(null, ErrorCode.ERROR_STRING[2]);
				SplashCertify.disposeSplash();
				this.dispose();
				return;
			}
		} catch (ConnectException ce) {
			JOptionPane.showMessageDialog(null, "����ͼƬ������ʧ��(Connect),����ϵͳ֧����Ա��ϵ��");
			SplashCertify.disposeSplash();
			this.dispose();
			throw ce;
		} catch (NullPointerException nullEx) { //��ָ���쳣ʱ������Ϣ��ʾ
			JOptionPane.showMessageDialog(null, "����ͼƬ������ʧ��(NullPoint),����ϵͳ֧����Ա��ϵ��");
			SplashCertify.disposeSplash();
			this.dispose();
			return;
		} catch (IOException ioEx) { //I/O�쳣
			JOptionPane.showMessageDialog(null, "����ͼƬ������ʧ��(I/O),����ϵͳ֧����Ա��ϵ��");
			SplashCertify.disposeSplash();
			this.dispose();
			return;
		} catch (Exception ConnectException) { //�����쳣
			JOptionPane.showMessageDialog(null, "����ͼƬ������ʧ��(Error),����ϵͳ֧����Ա��ϵ��");
			SplashCertify.disposeSplash();
			this.dispose();
			return;
		}
		//Modify by wangwei shield end 2006-02-10

		for (int i = 0; i < imageTypeList.size(); i++) {
			PrpDcodeDto prpDcodeDto = (PrpDcodeDto) imageTypeList.get(i);

			//        if(prpDcodeDto.getCodeCode().substring(0,1).equals(prpLImageDto.getCertiType().trim())){
			prpLImageDtoTemp = new PrpLImageDto();

			//copy����        
			copyDtoProperties(prpLImageDtoTemp, prpLImageDto);

			//���� 
			JLabel labelTitle = new JLabel(prpDcodeDto.getCodeCName() + "��");
			labelTitle.setFont(new java.awt.Font("����", 1, 11));
			labelTitle.setForeground(new Color(12, 12, 12));
			labelTitle.setRequestFocusEnabled(true);
			labelTitle.setHorizontalAlignment(SwingConstants.CENTER);
			c.anchor = GridBagConstraints.EAST;
			c.gridx = 0;
			c.gridy = serialNo;
			jPaneFrame.add(labelTitle, c);

			//Modify by wangwei update start 2005-12-19
			//Reanson��ͼƬ��ŵ�·������/�±���
			int month = new DateTime(prpLImageDtoTemp.getSignInDate()).getMonth();

			String httpSavePath = "/" + prpLImageDtoTemp.getUploadYear() + "/" + month + "/"
					+ prpLImageDtoTemp.getRiskCode() + "/" + prpLImageDtoTemp.getRegistNo() + "/"
					+ prpDcodeDto.getCodeCode() + prpLImageDtoTemp.getLossItemCode();

			//Modify by wangwei update end 2005-12-19
			/*            
			 String httpSavePath = "/" + prpLImageDtoTemp.getUploadYear()+ "/"
			 + prpLImageDtoTemp.getRiskCode()+"/"+prpLImageDtoTemp.getRegistNo()
			 + "/"+prpDcodeDto.getCodeCode()+prpLImageDtoTemp.getLossItemCode();
			 */
			typecode = prpDcodeDto.getCodeCode();

			//ͼƬdto����ֵ 
			prpLImageDtoTemp.setTypeCode(prpDcodeDto.getCodeCode());
			prpLImageDtoTemp.setTypeName(prpDcodeDto.getCodeCName());
			prpLImageDtoTemp.setFtpSavePath(httpSavePath);

			ListModel model1 = null;

			//            if (collectionhttp.size()>0)
			//            model1 = new HttpImageFileListModel(collectionhttp, prpLImageDtoTemp.getTypeCode());

			try {
				model1 = new HttpImageFileListModel(collectionhttp, typecode);
			} catch (Exception ConnectException) { //�����쳣
				JOptionPane.showMessageDialog(null, "initͼƬ��ʾģʽʧ��(Error),����ϵͳ֧����Ա��ϵ��");
				SplashCertify.disposeSplash();
				this.dispose();
				return;
			}

			list1 = new JList(model1);
			list1.addMouseListener(new ListImageViewerAdapter(list1, prpLImageDtoTemp));
			list1.setCellRenderer(renderer);
			list1.setVisibleRowCount(3);

			c.gridx = 1;
			c.gridy = serialNo;
			JScrollPane jScrollPaneShow = new JScrollPane(list1);

			c.anchor = GridBagConstraints.CENTER;
			c.fill = GridBagConstraints.BOTH;

			jPaneFrame.add(jScrollPaneShow, c);
			c.fill = GridBagConstraints.NONE;

			//ѹ����־
			JCheckBox checkCompress = new JCheckBox("ѹ��");
			checkCompress.setSelected(true);
			checkCompress.setEnabled(false);

			c.gridx = 2;
			c.gridy = serialNo;
			jPaneFrame.add(checkCompress, c);

			//�ϴ�
			JButton uploadButton = new JButton("�ϴ�");
			uploadButton.addActionListener(new ImageUploadListener(this, httpClient, prpLImageDtoTemp, maxImageWidth,
					compressionQuality, checkCompress, list1));
			c.gridx = 3;
			c.gridy = serialNo;

			jPaneFrame.add(uploadButton, c);
			//Modify by wangwei add start 2006-02-10
			//Reason: ������ʾͼƬ��ť
			/*            
			 JButton showButton = new JButton("ͼƬ��ʾ");
			 showButton.addActionListener(new ActionListener() {
			 private PrpLImageDto prpLImageDtoNew = prpLImageDtoTemp;
			 private JList jListNew = list1;
			 public void actionPerformed(ActionEvent e) {
			 try {
			 collectionhttp = httpClient.getcollect(prpLImageDtoNew);
			 httpClient.mget(collectionhttp);
			 ((HttpImageFileListModel) jListNew.getModel()).setTypeCode(prpLImageDtoNew.getTypeCode());
			 ((HttpImageFileListModel) jListNew.getModel()).setCollection(collectionhttp);
			 ((HttpImageFileListModel) jListNew.getModel()).refresh();
			 } catch (Exception ex) {
			 JOptionPane.showMessageDialog(null, "����ͼƬ������ʧ��(Error),����ϵͳ֧����Ա��ϵ��");
			 SplashCertify.disposeSplash();
			 return;         
			 }
			 }
			 });
			 c.gridx = 4;
			 c.gridy = serialNo;
			 jPaneFrame.add(showButton, c);
			 //Modify by wangwei add end 2006-02-10
			 */
			serialNo++;
			//          }                    
		}
		JMenuBar mb = new JMenuBar();
		mb.add(mainMenu); //mb.add(createAbleMenu());
		setJMenuBar(mb);

	}

	protected void createActionComponents(JToolBar toolBar, JMenu mainMenu) {
		JButton button = null;
		JMenuItem menuItem = null;

		//first button and menu item
		leftAction = new AbstractAction("�ر�", new ImageIcon("images/left.gif")) {
			public void actionPerformed(ActionEvent e) {
				if (JOptionPane.showConfirmDialog(new JFrame(), "�˳���֤�ϴ����� ?", "��ʾ��Ϣ", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
					dispose();

			}
		};
		button = toolBar.add(leftAction);
		button.setText("��֤�ϴ�"); //an icon-only button
		menuItem = mainMenu.add(leftAction);
		menuItem.setIcon(null); //arbitrarily chose not to use icon in menu
	}

	/**
	 * clone dto
	 */
	public void copyDtoProperties(PrpLImageDto prpLImageDtoTo, PrpLImageDto prpLImageDtoFrom) {
		prpLImageDtoTo.setMaxImageWidth(prpLImageDtoFrom.getMaxImageWidth());
		prpLImageDtoTo.setMaxImageHeight(prpLImageDtoFrom.getMaxImageHeight());
		prpLImageDtoTo.setCertiType(prpLImageDtoFrom.getCertiType());
		prpLImageDtoTo.setLossItemCode(prpLImageDtoFrom.getLossItemCode());
		prpLImageDtoTo.setNodeType(prpLImageDtoFrom.getNodeType());
		prpLImageDtoTo.setRegistNo(prpLImageDtoFrom.getRegistNo());
		prpLImageDtoTo.setCompressionQuality(prpLImageDtoFrom.getCompressionQuality());
		prpLImageDtoTo.setTypeCode(prpLImageDtoFrom.getTypeCode());
		prpLImageDtoTo.setUploadFileName(prpLImageDtoFrom.getUploadFileName());
		prpLImageDtoTo.setCollectorName(prpLImageDtoFrom.getCollectorName());
		prpLImageDtoTo.setImgSize(prpLImageDtoFrom.getImgSize());
		prpLImageDtoTo.setFtpSavePath(prpLImageDtoFrom.getFtpSavePath());
		prpLImageDtoTo.setDisPlayName(prpLImageDtoFrom.getDisPlayName());
		prpLImageDtoTo.setImgFileName(prpLImageDtoFrom.getImgFileName());
		prpLImageDtoTo.setLossItemName(prpLImageDtoFrom.getLossItemName());
		prpLImageDtoTo.setUploadYear(prpLImageDtoFrom.getUploadYear());
		prpLImageDtoTo.setRiskCode(prpLImageDtoFrom.getRiskCode());
		prpLImageDtoTo.setFtpPass(prpLImageDtoFrom.getFtpPass());
		prpLImageDtoTo.setFtpUrl(prpLImageDtoFrom.getFtpUrl());
		prpLImageDtoTo.setFtpUser(prpLImageDtoFrom.getFtpUser());
		prpLImageDtoTo.setImgFileCount(prpLImageDtoFrom.getImgFileCount());
		prpLImageDtoTo.setImgFileCapabillity(prpLImageDtoFrom.getImgFileCapabillity());
		prpLImageDtoTo.setWebUrl(prpLImageDtoFrom.getWebUrl());
		prpLImageDtoTo.setStrImageTypeList(prpLImageDtoFrom.getStrImageTypeList());
		prpLImageDtoTo.setStrTitleList(prpLImageDtoFrom.getStrTitleList());
		prpLImageDtoTo.setImgUrl(prpLImageDtoFrom.getImgUrl());
		prpLImageDtoTo.setPolicyNo(prpLImageDtoFrom.getPolicyNo());
		prpLImageDtoTo.setSignInDate(prpLImageDtoFrom.getSignInDate());
	}

	public void splash() throws MalformedURLException {
	}

}
