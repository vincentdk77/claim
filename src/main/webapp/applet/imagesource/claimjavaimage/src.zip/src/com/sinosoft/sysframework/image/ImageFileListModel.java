/**
 * @author lijiyuan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * Author:Mr.Li    lijiyuan create version  1.0 
 */

package com.sinosoft.sysframework.image;
import javax.swing.*;
/**
 * ����ʾ���ƺ�ͼƬ��ListModel
 */ 
public class ImageFileListModel extends DefaultListModel {
    protected ImageFileListModel() {
    }
    public ImageFileListModel(String[] names, String[] pics) {
        for (int i = 0; i < names.length; ++i) {
            addElement(new Object[]{names[i], new ImageIcon(pics[i]), ""});
        }
    }
    public String getName(Object object) {
        Object[] array = (Object[]) object;
        return (String) array[0];
    }
    public Icon getIcon(Object object) {
        Object[] array = (Object[]) object;
        return (Icon) array[1];
    }
    public String getFileName(Object object) {
        Object[] array = (Object[]) object;
        return (String) array[0];
    }
}
