/**
 * @author lijiyuan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * Author:Mr.Li    lijiyuan create version  1.0 
 */

package com.sinosoft.sysframework.common.util;
/**
 * Swing������
 */
import java.awt.*;
import javax.swing.text.JTextComponent;
public class SwingUtils {
    /**
     * Ĭ�Ϲ��캯��,��ֹʵ����
     */
    private SwingUtils() { 
    }
    /**
     * Find the hosting frame
     * 
     * @param c component
     * @return hosting frame
     */
    public static Frame getFrame(Component c) {
        for (Container p = c.getParent(); p != null; p = p.getParent()) {
            if (p instanceof Frame) {
                return (Frame) p;
            }
        }
        return null;
    }
    /**
     * Find the hosting dialog
     * 
     * @param c component
     * @return hosting dialog
     */
    public static Dialog getDialog(Component c) {
        for (Container p = c.getParent(); p != null; p = p.getParent()) {
            if (p instanceof Dialog) {
                return (Dialog) p;
            }
        }
        return null;
    }
    /**
     * ʹwindow��λ����Ļ�м�
     * 
     * @param frame window
     */
    public static void center(Window frame) {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = frame.getSize();
        frame.setLocation(screenSize.width / 2 - (frameSize.width / 2), screenSize.height / 2 - (frameSize.height / 2));
    }
    /**
     * �Ƿ�û������
     * 
     * @param textComponent �ı��ؼ�
     * @return ����ı��ؼ�����Ϊnull��գ��򷵻�true,���򷵻�false
     */
    public static boolean isEmpty(JTextComponent textComponent) {
        if (textComponent.getText() == null || textComponent.getText().length() == 0) {
            return true;
        }
        return false;
    }
}
