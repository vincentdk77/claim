package com.sinosoft.imagetrans;
/*
 * @(#)SplashCertify.java  2.2  2005-04-03
 *
 * Copyright (c) 2003-2005 Werner Randelshofer
 * Staldenmattweg 2, Immensee, CH-6405, Switzerland.
 * All rights reserved.
 *
 * This software is in the public domain.
 * Author:Mr.Li    lijiyuan create version  1.0 
 */

import java.awt.*;
import java.awt.event.*;
import java.awt.image.ImageProducer;
import java.net.*;
import java.io.*;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JWindow;

public class SplashCertify extends JWindow {
    private static SplashCertify instance;
    private JProgressBar progress;    
    private Image image;
    
    private boolean paintCalled = false;
    
    private SplashCertify(Frame parent, Image image) {
        super(parent);
        this.image = image;
        
        MediaTracker mt = new MediaTracker(this);
        mt.addImage(image,0);
        try {
            mt.waitForID(0);
        } catch(InterruptedException ie){}
        
        int imgWidth = image.getWidth(this);
        int imgHeight = image.getHeight(this);
        setSize(imgWidth, imgHeight);
        Dimension screenDim = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(
        (screenDim.width - imgWidth) / 2,
        (screenDim.height - imgHeight) / 2
        );
        
       
        MouseAdapter disposeOnClick = new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                synchronized(SplashCertify.this) {
                	SplashCertify.this.paintCalled = true;
                	SplashCertify.this.notifyAll();
                }
                dispose();
            }
        };
        addMouseListener(disposeOnClick);
    }
    
    public void update(Graphics g) {
        paint(g);
    }



    public void paint(Graphics g) {
        g.drawImage(image, 0, 0, this);
        if (! paintCalled) {
            paintCalled = true;
            synchronized (this) { notifyAll(); }
        }
    }
    
    public static void splash(Image image) {
        if (instance == null && image != null) {
            Frame f = new Frame();
            
            instance = new SplashCertify(f, image);
            
            instance.show();

            if (! EventQueue.isDispatchThread() 
            && Runtime.getRuntime().availableProcessors() == 1) {
                synchronized (instance) {
                    while (! instance.paintCalled) {
                        try { instance.wait(); } catch (InterruptedException e) {}
                    }
                }
            }
        }
    }



    public static void splash(URL imageURL) {
    	ImageProducer a;
            if (imageURL != null) {
                splash(Toolkit.getDefaultToolkit().createImage(imageURL));
            }
            
    }
    



    public static void disposeSplash() {
        if (instance != null) {
        	instance.getOwner().dispose();        	
            instance = null;
        }
    }

}
