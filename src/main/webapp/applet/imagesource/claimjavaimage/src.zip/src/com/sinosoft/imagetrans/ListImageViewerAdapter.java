/**
 * @author lijiyuan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * Author:Mr.Li    lijiyuan create version  1.0 
 */

package com.sinosoft.imagetrans;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JList;

import com.sinosoft.sysframework.image.ImageFileListModel;
import com.sinosoft.claim.dto.custom.PrpLImageDto;
import com.sinosoft.sysframework.image.ImageViewer;
/**
 * ����JList��ImageViewerAdapter
 */
public class ListImageViewerAdapter extends MouseAdapter {
    private JList list = null;
    private PrpLImageDto prpLImageDto = null;    
    public ListImageViewerAdapter(JList list,PrpLImageDto prpLImageDtoTemp) {
    	this.prpLImageDto=prpLImageDtoTemp;    	
        this.list = list;
    }
   
    public void mouseClicked(MouseEvent e) {
        if (e.getClickCount() == 2) {
            ImageFileListModel model = (ImageFileListModel) list.getModel();
            String fileName = model.getFileName(model.getElementAt(list
                    .getSelectedIndex()));
            ImageViewer imageViewer;
			try {
				imageViewer = new ImageViewer(fileName,prpLImageDto);
				imageViewer.pack();
	            		imageViewer.setVisible(true);
				
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        }
    }
}
