/**
 * @author lijiyuan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * Author:Mr.Li    lijiyuan create version  1.0 
 */

package com.sinosoft.imagetrans;



import java.util.*;   


import javax.swing.ImageIcon;

import com.sinosoft.claim.dto.domain.PrpLcertifyImgDto;
import com.sinosoft.sysframework.image.ImageFileListModel;
import com.sinosoft.sysframework.transfer.CommonClass;
import com.sinosoft.sysframework.transfer.HttpClient;
import com.sinosoft.sysframework.common.util.StringUtils;


/**
 * �б���ʾͼƬ 
 */
public class HttpImageFileListModel extends ImageFileListModel {

    private static ArrayList collection;
    private String typecode;
    private static String unladdressall;
    /**
     * @throws Exception
     */

    public HttpImageFileListModel()  {
    }	
    public HttpImageFileListModel(ArrayList collection1,String typecode) throws Exception {
        collection=collection1;
        this.typecode=typecode;
        refresh();
        
    }
    /**
     * ˢ��
     * 
     * @throws Exception
     */
    public void refresh() throws Exception {
         removeAllElements();  
	     HttpClient httpClient=new HttpClient();
	     String tempPath = System.getProperty("java.io.tmpdir");	
	     tempPath = tempPath.replace('\\', '/');
	     for (int i = 0; i < collection.size(); i++) {
		 PrpLcertifyImgDto prpLcertifyImgDto = (PrpLcertifyImgDto)collection.get(i);
		 if (prpLcertifyImgDto.getTypeCode().equals(typecode)){
		    	String filename=CommonClass.PRE_FIX+prpLcertifyImgDto.getImgFileName();
		    	String unladdress=tempPath+HttpClient.getRootPath()+prpLcertifyImgDto.getPicPath()+"/"+filename;
	            ImageIcon imageIcon =new ImageIcon(unladdress);
	            addElement(new Object[]{prpLcertifyImgDto.getImgFileName(),imageIcon, ""});
			}
       	}						
    }	

    public void setTypeCode(String typeCode){
        this.typecode= StringUtils.rightTrim(typeCode);
    }

    public void setCollection(ArrayList collection1){
        collection= collection1;
    }
    public ArrayList getCollection(){
        return  collection;
    }
    public String  getUnlAddressAll(){
        return  unladdressall;
    }
	
	
  }
