/**
 * @author lijiyuan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * Author:Mr.Li    lijiyuan create version  1.0 
 */
package com.sinosoft.sysframework.transfer;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.*;
import java.io.InputStream;
import java.io.ObjectOutputStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;   

import javax.swing.JOptionPane;


import com.sinosoft.sysframework.common.util.FileUtils;
import com.sinosoft.claim.dto.custom.PrpLImageDto;
import com.sinosoft.claim.dto.domain.PrpLcertifyImgDto;



import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGImageDecoder;
import com.sun.image.codec.jpeg.JPEGImageEncoder;





/**
*
*/
public class HttpClient {
   private static String serverURL = "";
   private String unlPath = "";
   private static String rootPath="dubang";	


	
   private String pwd;
   /**
    * @param serverURL
    */
   public HttpClient(String serverURLadress) {
       super();
       serverURL = serverURLadress;
   }

   public HttpClient() {
   }

	
   public void mkdirs(String dirs) {
   }

   public void cd(String dir) {
       pwd = dir;
   }
   
   public void mput(String[] localFiles, String[] remoteFiles,String[] xmlDatas,String[] filename) throws Exception {
       for (int i = 0; i < remoteFiles.length; i++) {
           put(localFiles[i], remoteFiles[i], xmlDatas[i], filename[i]);
       }
   }
   
   private void put(String localFile, String remoteFile,String xmlData,String filename) throws Exception {
       URL url = new URL(serverURL);
       HttpURLConnection con = (HttpURLConnection) url.openConnection();
       con.setDoOutput(true);
       con.setDoInput(true);
       con.setRequestMethod("POST");
       con.setUseCaches(false);
       con.setDefaultUseCaches(false);
       con.setRequestProperty("Content-Type", "application/octet-stream");
       con.connect();
       ObjectOutputStream out = new ObjectOutputStream(con.getOutputStream());
       byte[] fileData = FileUtils.readBytes(localFile);
       remoteFile = remoteFile.replace('\\', '/');

       if (remoteFile.indexOf("/") == -1) {
           remoteFile = pwd + "/" + remoteFile;
       }

       out.writeObject(new Integer(CommonClass.STEP3));
       out.writeObject(remoteFile);
       out.writeObject(fileData);
       out.writeObject(xmlData.getBytes("GB2312"));
       out.writeObject(filename);	   
       out.flush();
       out.close();
       
       InputStream in = con.getInputStream();
////       int c;
////       do {
////           char x;
////           c = in.read();
////           x = (char) c;
////           if (c != -1) {
////               System.out.print("why ?======" + x);
////           }
////       } while (c != -1);
       in.close();
   }

   public ArrayList getcollect(PrpLImageDto prpLImageDtoTemp) 
                    throws ConnectException, IOException, Exception {
	 String sendtype="";
	 String businessno="";
 	 String strReturn="";
	 String returntype="";
	 
	try{ 
	   URL	url = new URL(serverURL);
System.err.println(CommonClass.PRINT_STRING[4]+serverURL);   	

System.err.println("���е�"+prpLImageDtoTemp.getTypeCode());

	   HttpURLConnection con = (HttpURLConnection) url.openConnection();
	    
       con.setDoOutput(true);
       con.setDoInput(true);
       con.setRequestMethod("POST");
       con.setUseCaches(false);
       con.setDefaultUseCaches(false);
       con.setRequestProperty("Content-Type", "application/octet-stream");
       con.connect();

       
       ObjectOutputStream out = new ObjectOutputStream(con.getOutputStream());
       out.writeObject(new Integer(CommonClass.STEP2));
       out.writeObject(prpLImageDtoTemp.getRegistNo());
       out.writeObject(prpLImageDtoTemp.getLossItemCode());  //���ӱ����Ϣ
//       out.writeObject(prpLImageDtoTemp.getTypeCode());     //���ӵ�֤����  2005-12-19
       out.writeObject(prpLImageDtoTemp.getCertiType());     //���ӵ�֤����  2005-12-19
       out.flush();
       out.close();
       
	   ObjectInputStream is = new ObjectInputStream(con.getInputStream());
	   ArrayList collection=(ArrayList) is.readObject();
	   is.close();
System.err.println(CommonClass.PRINT_STRING[5]+collection.size());
	   return collection;
	} catch (ConnectException ce){
		throw ce;
	} catch (IOException ioEx) {
	    throw ioEx;	    
	}
   	}

   public String getUnlPath(){
       return unlPath;
   }	


   public int   mget(ArrayList collection) throws Exception {
   	     int returntype=0;
   	     PrpLcertifyImgDto prpLcertifyImgDto = null;

	     if (collection.size()>0){
	         String tempPath = System.getProperty("java.io.tmpdir");  //�õ�����ϵͳ��ʱĿ¼·����Ϣ	
			 java.io.File myFilePath = new java.io.File(tempPath);
			 if (myFilePath.exists()) {                               //ɾ������ϵͳ��ʱĿ¼�µ������ļ�
		 	     FileUtils.delAllFile(tempPath+"/"+getRootPath());
			 }
	     }
	     
	     for (int i = 0; i < collection.size(); i++) {
			prpLcertifyImgDto = (PrpLcertifyImgDto)collection.get(i);
			returntype=get(prpLcertifyImgDto.getPicPath(), prpLcertifyImgDto.getImgFileName());
			if (returntype==CommonClass.RETURNTYPE) {
				return CommonClass.RETURNTYPE;
			}
		}
		 return 1;
   }

   private int  get(String dirfile,String filename) throws Exception {

	 String sendtype="";
 	 String strReturn="";
	 String returntype="";

	 String address=dirfile+"/"+filename;	 
	 URL	url = new URL(serverURL);
	 HttpURLConnection con = (HttpURLConnection) url.openConnection();
       con.setDoOutput(true);
       con.setDoInput(true);
       con.setRequestMethod("POST");
       con.setUseCaches(false);
       con.setDefaultUseCaches(false);
       con.setRequestProperty("Content-Type", "application/octet-stream");
       con.connect();
       ObjectOutputStream out = new ObjectOutputStream(con.getOutputStream());
       out.writeObject(new Integer(CommonClass.STEP1));
       out.writeObject(address);
       out.flush();
       out.close();
	ObjectInputStream is = new ObjectInputStream(con.getInputStream());
    String getInputMsg= (String) is.readObject();
    if (getInputMsg.equals("error_a")){
      	is.close();    	
    	return CommonClass.RETURNTYPE;
    }
    if (getInputMsg.equals("success")){
	byte[] fileData = (byte[]) is.readObject();
	
	String tempPath = System.getProperty("java.io.tmpdir");	
	tempPath = tempPath.replace('\\', '/');
	String dir=  tempPath+getRootPath()+""+dirfile;
	File file=null;    	
	file=new File(dir);
	if(!file.exists()) {
	  file.mkdirs();
	}
	  String newfilename= dir+ "/" +filename;
	  String prefixname= dir+ "/"+CommonClass.PRE_FIX+filename;
      FileUtils.write(fileData, newfilename);    //�ѷ�����ͼƬ���ص�������ʱ�ļ����У���ͼƬ��
	  setBreviary(prefixname,newfilename);       //�ѷ�����ͼƬ���ص�������ʱ�ļ����У��ұ����С����СͼƬ��
    }  
	  is.close();
	  return 1;
   }

   private void setBreviary(String breviary,String filename) throws FileNotFoundException{

   	try{   	
		InputStream imageStream = new FileInputStream(filename);
		JPEGImageDecoder decoderFile = JPEGCodec.createJPEGDecoder(imageStream);
		BufferedImage imageFile = decoderFile.decodeAsBufferedImage();
		float zoom = 0.2F;
		int w = (int) (imageFile.getWidth() * zoom);
		int h = (int) (imageFile.getHeight() * zoom);
		BufferedImage bufImage = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
		Graphics g = bufImage.getGraphics();
        g.drawImage(imageFile, 0, 0, w, h, null);
		FileOutputStream out = new FileOutputStream(breviary);
		JPEGImageEncoder jpeg = JPEGCodec.createJPEGEncoder(out);
		jpeg.encode(bufImage);
		out.flush();
		out.close();
		imageStream.close();
    } catch(Exception ex){
		ex.printStackTrace(); 
	}
   	}

    public static String getRootPath() {
        return rootPath;
    }   

   
}
